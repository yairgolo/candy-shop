from __future__ import annotations

import asyncio, json, os, sys, tempfile
from pathlib import Path
from flask import Flask, jsonify, render_template, request
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from openai import AsyncOpenAI

from .db import connect
from .event_catalog import explain
from .import_logs import import_csv, import_evtx
from .chat import SYSTEM, mcp_tools_to_openai, content_to_text

ROOT = Path(__file__).resolve().parents[1]
UPLOADS = ROOT / "data" / "uploads"
UPLOADS.mkdir(parents=True, exist_ok=True)
LLM_URL = os.getenv("LLM_URL", "http://127.0.0.1:8080/v1")
LLM_MODEL = os.getenv("LLM_MODEL", "local-qwen")

app = Flask(__name__, template_folder=str(ROOT / "templates"), static_folder=str(ROOT / "static"))
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024 * 1024


def filters_from_args(args):
    return {
        "event_id": args.get("event_id", "").strip(),
        "computer": args.get("computer", "").strip(),
        "username": args.get("username", "").strip(),
        "source_ip": args.get("source_ip", "").strip(),
        "text": args.get("text", "").strip(),
        "start": args.get("start", "").strip(),
        "end": args.get("end", "").strip(),
    }


def build_where(f):
    clauses, params = [], []
    if f["event_id"]:
        clauses.append("event_id = ?"); params.append(int(f["event_id"]))
    if f["computer"]:
        clauses.append("computer LIKE ?"); params.append(f"%{f['computer']}%")
    if f["username"]:
        clauses.append("username LIKE ?"); params.append(f"%{f['username']}%")
    if f["source_ip"]:
        clauses.append("source_ip LIKE ?"); params.append(f"%{f['source_ip']}%")
    if f["text"]:
        clauses.append("(message LIKE ? OR process_name LIKE ? OR raw_xml LIKE ?)"); params.extend([f"%{f['text']}%"]*3)
    if f["start"]:
        clauses.append("timestamp >= ?"); params.append(f["start"])
    if f["end"]:
        clauses.append("timestamp <= ?"); params.append(f["end"])
    return " AND ".join(clauses) if clauses else "1=1", params


@app.get("/")
def dashboard():
    con = connect()
    total = con.execute("SELECT COUNT(*) FROM events").fetchone()[0]
    failed = con.execute("SELECT COUNT(*) FROM events WHERE event_id=4625").fetchone()[0]
    processes = con.execute("SELECT COUNT(*) FROM events WHERE event_id=4688").fetchone()[0]
    changes = con.execute("SELECT COUNT(*) FROM events WHERE event_id IN (4697,4720,4722,4724,4726,4732,4733,7045,1102)").fetchone()[0]
    cleared = con.execute("SELECT COUNT(*) FROM events WHERE event_id=1102").fetchone()[0]
    top_ids = [dict(r) for r in con.execute("SELECT event_id,COUNT(*) count FROM events GROUP BY event_id ORDER BY count DESC LIMIT 8")]
    top_hosts = [dict(r) for r in con.execute("SELECT computer,COUNT(*) count FROM events WHERE computer IS NOT NULL GROUP BY computer ORDER BY count DESC LIMIT 8")]
    con.close()
    return render_template("dashboard.html", total=total, failed=failed, processes=processes, changes=changes, cleared=cleared, top_ids=top_ids, top_hosts=top_hosts)


@app.get("/logs")
def logs_page():
    return render_template("logs.html")


@app.get("/api/logs")
def api_logs():
    f = filters_from_args(request.args)
    try: page=max(1,int(request.args.get("page",1))); size=min(200,max(10,int(request.args.get("size",50))))
    except ValueError: page,size=1,50
    where, params = build_where(f)
    con=connect()
    total=con.execute(f"SELECT COUNT(*) FROM events WHERE {where}", params).fetchone()[0]
    rows=con.execute(f"SELECT id,event_id,timestamp,computer,username,source_ip,process_name,provider,channel,message,raw_xml FROM events WHERE {where} ORDER BY timestamp DESC LIMIT ? OFFSET ?", (*params,size,(page-1)*size)).fetchall()
    con.close()
    return jsonify({"total":total,"page":page,"size":size,"events":[dict(r) for r in rows]})


@app.get("/api/event/<int:row_id>")
def api_event(row_id):
    con=connect(); row=con.execute("SELECT * FROM events WHERE id=?",(row_id,)).fetchone(); con.close()
    if not row: return jsonify({"error":"not found"}),404
    out=dict(row); out["catalog"]=explain(out["event_id"])
    return jsonify(out)


@app.get("/chat")
def chat_page():
    return render_template("chat.html")


async def ask_llm(question: str, history: list[dict] | None = None):
    client=AsyncOpenAI(base_url=LLM_URL, api_key="not-needed")
    server=StdioServerParameters(command=sys.executable,args=["-m","app.mcp_server"],cwd=str(ROOT),env={**os.environ})
    async with stdio_client(server) as (read,write):
        async with ClientSession(read,write) as session:
            await session.initialize(); listed=await session.list_tools(); tools=mcp_tools_to_openai(listed.tools)
            messages=[{"role":"system","content":SYSTEM + "\nAnswer in Hebrew by default. Keep tool result summaries compact."}]
            for m in (history or [])[-8:]:
                if m.get("role") in {"user","assistant"} and isinstance(m.get("content"),str): messages.append({"role":m["role"],"content":m["content"]})
            messages.append({"role":"user","content":question})
            used=[]
            for _ in range(6):
                resp=await client.chat.completions.create(model=LLM_MODEL,messages=messages,tools=tools,tool_choice="auto",temperature=0.1,max_tokens=700)
                msg=resp.choices[0].message
                am={"role":"assistant","content":msg.content or ""}
                if msg.tool_calls: am["tool_calls"]=[tc.model_dump() for tc in msg.tool_calls]
                messages.append(am)
                if not msg.tool_calls: return {"answer":msg.content or "","tools":used}
                for call in msg.tool_calls:
                    try:
                        args=json.loads(call.function.arguments or "{}")
                        result=await session.call_tool(call.function.name,arguments=args)
                        payload=content_to_text(result)
                        used.append({"name":call.function.name,"arguments":args})
                    except Exception as exc: payload=json.dumps({"error":str(exc)},ensure_ascii=False)
                    messages.append({"role":"tool","tool_call_id":call.id,"content":payload})
            return {"answer":"הגעתי למגבלת קריאות הכלים לשאלה הזאת.","tools":used}


@app.post("/api/chat")
def api_chat():
    body=request.get_json(silent=True) or {}; q=(body.get("question") or "").strip()
    if not q: return jsonify({"error":"question is required"}),400
    try: return jsonify(asyncio.run(ask_llm(q, body.get("history") or [])))
    except Exception as exc: return jsonify({"error":str(exc)}),500


@app.get("/upload")
def upload_page():
    return render_template("upload.html")


@app.post("/api/upload")
def api_upload():
    file=request.files.get("file")
    if not file or not file.filename: return jsonify({"error":"בחר קובץ"}),400
    suffix=Path(file.filename).suffix.lower()
    if suffix not in {".evtx",".csv"}: return jsonify({"error":"נתמכים רק EVTX או CSV"}),400
    safe_name=Path(file.filename).name
    dest=UPLOADS/safe_name; file.save(dest)
    try: count=import_evtx(dest) if suffix==".evtx" else import_csv(dest)
    except Exception as exc: return jsonify({"error":str(exc)}),500
    return jsonify({"ok":True,"filename":safe_name,"imported":count})


if __name__ == "__main__":
    app.run(host="127.0.0.1",port=int(os.getenv("WEB_PORT","5000")),debug=False)
