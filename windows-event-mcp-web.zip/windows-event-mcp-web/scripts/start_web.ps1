$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)
if (-not (Test-Path ".\.venv\Scripts\python.exe")) { throw "Missing .venv. Run: python -m venv .venv ; .\.venv\Scripts\python.exe -m pip install -r requirements.txt" }
& .\.venv\Scripts\python.exe -m app.web
