# EventScope Web UI

1. `python -m venv .venv`
2. `.\.venv\Scripts\Activate.ps1`
3. `pip install -r requirements.txt`
4. Import sample: `python -m app.import_logs .\samples\sample_events.csv`
5. Start llama.cpp with the local Qwen GGUF on port 8080 and `--jinja`.
6. Start web: `python -m app.web` or `.\scripts\start_web.ps1`
7. Open `http://127.0.0.1:5000`

Pages: Dashboard `/`, Chat `/chat`, Logs `/logs`, Import `/upload`.
All CSS/JS is local; no CDN or internet dependency at runtime.
