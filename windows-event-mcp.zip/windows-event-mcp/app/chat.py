from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from openai import AsyncOpenAI

ROOT = Path(__file__).resolve().parents[1]
LLM_URL = os.getenv("LLM_URL", "http://127.0.0.1:8080/v1")
LLM_MODEL = os.getenv("LLM_MODEL", "local-qwen")

SYSTEM = """You are an offline Windows security log analyst. The user may write Hebrew or English.
Use the supplied MCP tools whenever the question depends on log data. Never invent events that were not returned by tools.
For vague investigation requests, first inspect database_stats or investigate_host as appropriate.
Keep answers concise and practical. Mention relevant Windows Event IDs. If data is missing, say exactly what is missing.
All data and tools are local; there is no internet access."""

def mcp_tools_to_openai(tools):
    out = []
    for t in tools:
        out.append({
            "type": "function",
            "function": {
                "name": t.name,
                "description": t.description or "",
                "parameters": t.inputSchema or {"type": "object", "properties": {}},
            },
        })
    return out

def content_to_text(result) -> str:
    parts = []
    for item in result.content:
        text = getattr(item, "text", None)
        if text is not None:
            parts.append(text)
        else:
            parts.append(str(item))
    return "\n".join(parts)

async def run():
    client = AsyncOpenAI(base_url=LLM_URL, api_key="not-needed")
    server = StdioServerParameters(
        command=sys.executable,
        args=["-m", "app.mcp_server"],
        cwd=str(ROOT),
        env={**os.environ},
    )
    async with stdio_client(server) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            listed = await session.list_tools()
            tools = mcp_tools_to_openai(listed.tools)
            print("Windows Event MCP Assistant")
            print("Type 'exit' to quit. Example: כמה ניסיונות התחברות כושלים היו?\n")
            messages = [{"role": "system", "content": SYSTEM}]
            while True:
                try:
                    question = input("You> ").strip()
                except (EOFError, KeyboardInterrupt):
                    break
                if not question:
                    continue
                if question.lower() in {"exit", "quit", "q"}:
                    break
                messages.append({"role": "user", "content": question})

                for _ in range(8):
                    response = await client.chat.completions.create(
                        model=LLM_MODEL,
                        messages=messages,
                        tools=tools,
                        tool_choice="auto",
                        temperature=0.2,
                        max_tokens=1200,
                    )
                    msg = response.choices[0].message
                    assistant_msg = {"role": "assistant", "content": msg.content or ""}
                    if msg.tool_calls:
                        assistant_msg["tool_calls"] = [tc.model_dump() for tc in msg.tool_calls]
                    messages.append(assistant_msg)

                    if not msg.tool_calls:
                        print(f"AI> {msg.content}\n")
                        break

                    for call in msg.tool_calls:
                        try:
                            args = json.loads(call.function.arguments or "{}")
                            result = await session.call_tool(call.function.name, arguments=args)
                            payload = content_to_text(result)
                        except Exception as exc:
                            payload = json.dumps({"error": str(exc)}, ensure_ascii=False)
                        messages.append({
                            "role": "tool",
                            "tool_call_id": call.id,
                            "content": payload,
                        })
                else:
                    print("AI> Tool loop limit reached.\n")

if __name__ == "__main__":
    asyncio.run(run())
