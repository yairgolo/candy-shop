from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from typing import Any

from mcp.server.fastmcp import FastMCP

from .db import connect
from .event_catalog import explain

mcp = FastMCP("Windows Event Log MCP")
DB = os.getenv("EVENT_DB")
MAX_RESULTS = 200

def rows_to_dicts(rows):
    return [dict(r) for r in rows]

def build_where(event_id=None, computer=None, username=None, source_ip=None, text=None, start=None, end=None):
    clauses, params = [], []
    if event_id is not None:
        clauses.append("event_id = ?"); params.append(int(event_id))
    if computer:
        clauses.append("computer LIKE ?"); params.append(f"%{computer}%")
    if username:
        clauses.append("username LIKE ?"); params.append(f"%{username}%")
    if source_ip:
        clauses.append("source_ip LIKE ?"); params.append(f"%{source_ip}%")
    if text:
        clauses.append("(message LIKE ? OR process_name LIKE ? OR raw_xml LIKE ?)")
        params.extend([f"%{text}%"] * 3)
    if start:
        clauses.append("timestamp >= ?"); params.append(start)
    if end:
        clauses.append("timestamp <= ?"); params.append(end)
    return (" AND ".join(clauses) if clauses else "1=1"), params

@mcp.tool()
def search_events(event_id: int | None = None, computer: str | None = None, username: str | None = None,
                  source_ip: str | None = None, text: str | None = None, start: str | None = None,
                  end: str | None = None, limit: int = 50) -> dict[str, Any]:
    """Search imported Windows Event Logs. Use ISO timestamps for start/end. Filters can be combined."""
    limit = min(max(int(limit), 1), MAX_RESULTS)
    where, params = build_where(event_id, computer, username, source_ip, text, start, end)
    con = connect(DB)
    rows = con.execute(f"""SELECT event_id,timestamp,computer,username,source_ip,process_name,logon_type,message,provider,channel
                           FROM events WHERE {where} ORDER BY timestamp DESC LIMIT ?""", (*params, limit)).fetchall()
    con.close()
    return {"count": len(rows), "events": rows_to_dicts(rows)}

@mcp.tool()
def get_failed_logons(username: str | None = None, computer: str | None = None,
                      start: str | None = None, end: str | None = None, limit: int = 100) -> dict[str, Any]:
    """Return failed Windows logons (Security Event ID 4625), optionally filtered by user, computer and time."""
    return search_events(event_id=4625, username=username, computer=computer, start=start, end=end, limit=limit)

@mcp.tool()
def get_process_events(computer: str | None = None, text: str | None = None,
                       start: str | None = None, end: str | None = None, limit: int = 100) -> dict[str, Any]:
    """Return process creation events (Security Event ID 4688). text can match process path, command data or XML."""
    return search_events(event_id=4688, computer=computer, text=text, start=start, end=end, limit=limit)

@mcp.tool()
def get_security_changes(computer: str | None = None, start: str | None = None,
                         end: str | None = None, limit: int = 100) -> dict[str, Any]:
    """Return notable account/group/service/audit changes such as user creation/deletion, group membership, services and log clearing."""
    ids = (4697, 4720, 4722, 4724, 4726, 4732, 4733, 7045, 1102)
    limit = min(max(int(limit), 1), MAX_RESULTS)
    placeholders = ",".join("?" for _ in ids)
    clauses = [f"event_id IN ({placeholders})"]
    params: list[Any] = list(ids)
    if computer:
        clauses.append("computer LIKE ?"); params.append(f"%{computer}%")
    if start:
        clauses.append("timestamp >= ?"); params.append(start)
    if end:
        clauses.append("timestamp <= ?"); params.append(end)
    con = connect(DB)
    rows = con.execute(f"""SELECT event_id,timestamp,computer,username,source_ip,process_name,message
                           FROM events WHERE {' AND '.join(clauses)} ORDER BY timestamp DESC LIMIT ?""", (*params, limit)).fetchall()
    con.close()
    return {"count": len(rows), "events": rows_to_dicts(rows)}

@mcp.tool()
def explain_event(event_id: int) -> dict[str, Any]:
    """Explain a Windows Event ID using the built-in offline event catalog. No internet is used."""
    return explain(int(event_id))

@mcp.tool()
def investigate_host(computer: str, start: str | None = None, end: str | None = None, limit: int = 120) -> dict[str, Any]:
    """Build a compact investigation timeline for one host, emphasizing failed logons, privileged logons, process creation, account changes, services, lockouts and audit-log clearing."""
    interesting = (4625, 4648, 4672, 4688, 4697, 4720, 4724, 4726, 4732, 4740, 7045, 1102)
    limit = min(max(int(limit), 1), MAX_RESULTS)
    placeholders = ",".join("?" for _ in interesting)
    clauses = [f"event_id IN ({placeholders})", "computer LIKE ?"]
    params: list[Any] = [*interesting, f"%{computer}%"]
    if start:
        clauses.append("timestamp >= ?"); params.append(start)
    if end:
        clauses.append("timestamp <= ?"); params.append(end)
    con = connect(DB)
    rows = con.execute(f"""SELECT event_id,timestamp,computer,username,source_ip,process_name,logon_type,message
                           FROM events WHERE {' AND '.join(clauses)} ORDER BY timestamp ASC LIMIT ?""", (*params, limit)).fetchall()
    con.close()
    events = []
    for r in rows:
        item = dict(r)
        item["catalog"] = explain(item["event_id"])
        events.append(item)
    return {"computer": computer, "count": len(events), "timeline": events}

@mcp.tool()
def database_stats() -> dict[str, Any]:
    """Return basic statistics about the local imported Windows Event Log database."""
    con = connect(DB)
    total = con.execute("SELECT COUNT(*) FROM events").fetchone()[0]
    bounds = con.execute("SELECT MIN(timestamp), MAX(timestamp) FROM events").fetchone()
    top = con.execute("SELECT event_id, COUNT(*) AS count FROM events GROUP BY event_id ORDER BY count DESC LIMIT 10").fetchall()
    hosts = con.execute("SELECT COUNT(DISTINCT computer) FROM events WHERE computer IS NOT NULL").fetchone()[0]
    con.close()
    return {"total_events": total, "hosts": hosts, "first_timestamp": bounds[0], "last_timestamp": bounds[1], "top_event_ids": rows_to_dicts(top)}

if __name__ == "__main__":
    mcp.run(transport="stdio")
