from __future__ import annotations

import argparse
import csv
import re
import xml.etree.ElementTree as ET
from pathlib import Path

from .db import connect

NS = {"e": "http://schemas.microsoft.com/win/2004/08/events/event"}

def local(tag: str) -> str:
    return tag.split("}")[-1]

def get_text(node, path: str):
    found = node.find(path, NS)
    return found.text if found is not None else None

def event_data(root) -> dict[str, str]:
    out = {}
    for data in root.findall(".//e:EventData/e:Data", NS):
        name = data.attrib.get("Name")
        if name:
            out[name] = data.text or ""
    return out

def parse_evtx_xml(xml_text: str, source_file: str) -> dict:
    root = ET.fromstring(xml_text)
    system = root.find("e:System", NS)
    data = event_data(root)
    provider = None
    channel = None
    computer = None
    record_id = None
    timestamp = None
    event_id = None
    if system is not None:
        p = system.find("e:Provider", NS)
        provider = p.attrib.get("Name") if p is not None else None
        event_id = get_text(system, "e:EventID")
        record_id = get_text(system, "e:EventRecordID")
        channel = get_text(system, "e:Channel")
        computer = get_text(system, "e:Computer")
        tc = system.find("e:TimeCreated", NS)
        timestamp = tc.attrib.get("SystemTime") if tc is not None else None

    username = data.get("TargetUserName") or data.get("SubjectUserName") or data.get("AccountName")
    source_ip = data.get("IpAddress") or data.get("SourceNetworkAddress") or data.get("ClientAddress")
    process_name = data.get("NewProcessName") or data.get("ProcessName") or data.get("ImagePath")
    logon_type = data.get("LogonType")
    message_parts = [f"{k}={v}" for k, v in data.items() if v]

    return {
        "source_file": source_file,
        "record_id": int(record_id) if record_id and record_id.isdigit() else None,
        "event_id": int(event_id) if event_id and str(event_id).isdigit() else 0,
        "timestamp": timestamp,
        "computer": computer,
        "provider": provider,
        "channel": channel,
        "username": username,
        "source_ip": source_ip,
        "process_name": process_name,
        "logon_type": logon_type,
        "message": "; ".join(message_parts),
        "raw_xml": xml_text,
    }

def insert_many(con, rows):
    con.executemany(
        """INSERT INTO events
        (source_file, record_id, event_id, timestamp, computer, provider, channel, username, source_ip, process_name, logon_type, message, raw_xml)
        VALUES (:source_file, :record_id, :event_id, :timestamp, :computer, :provider, :channel, :username, :source_ip, :process_name, :logon_type, :message, :raw_xml)""",
        rows,
    )
    con.commit()

def import_evtx(path: Path, db: str | None = None) -> int:
    from Evtx.Evtx import Evtx
    con = connect(db)
    rows = []
    with Evtx(str(path)) as log:
        for record in log.records():
            try:
                rows.append(parse_evtx_xml(record.xml(), path.name))
            except Exception:
                continue
            if len(rows) >= 1000:
                insert_many(con, rows); rows.clear()
    if rows:
        insert_many(con, rows)
    count = con.execute("SELECT COUNT(*) FROM events WHERE source_file=?", (path.name,)).fetchone()[0]
    con.close()
    return count

def import_csv(path: Path, db: str | None = None) -> int:
    con = connect(db)
    rows = []
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            def first(*names):
                for n in names:
                    if r.get(n) not in (None, ""):
                        return r.get(n)
                return None
            eid = first("event_id", "EventID", "Id", "Event Id") or "0"
            rows.append({
                "source_file": path.name,
                "record_id": None,
                "event_id": int(re.sub(r"\D", "", eid) or 0),
                "timestamp": first("timestamp", "TimeCreated", "Date and Time", "TimeGenerated"),
                "computer": first("computer", "MachineName", "Computer"),
                "provider": first("provider", "ProviderName", "Source"),
                "channel": first("channel", "LogName"),
                "username": first("username", "TargetUserName", "User"),
                "source_ip": first("source_ip", "IpAddress", "SourceNetworkAddress"),
                "process_name": first("process_name", "NewProcessName", "ProcessName"),
                "logon_type": first("logon_type", "LogonType"),
                "message": first("message", "Message"),
                "raw_xml": first("raw_xml", "Xml"),
            })
    insert_many(con, rows)
    con.close()
    return len(rows)

def main():
    p = argparse.ArgumentParser(description="Import Windows Event Logs into SQLite")
    p.add_argument("path")
    p.add_argument("--db", default=None)
    args = p.parse_args()
    path = Path(args.path)
    if path.suffix.lower() == ".evtx":
        n = import_evtx(path, args.db)
    elif path.suffix.lower() == ".csv":
        n = import_csv(path, args.db)
    else:
        raise SystemExit("Supported formats: .evtx, .csv")
    print(f"Imported {n} events from {path}")

if __name__ == "__main__":
    main()
