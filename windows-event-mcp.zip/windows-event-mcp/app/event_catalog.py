EVENTS = {
    4624: ("Successful logon", "low", "An account successfully logged on."),
    4625: ("Failed logon", "medium", "An account failed to log on."),
    4634: ("Logoff", "low", "An account was logged off."),
    4648: ("Explicit credentials", "medium", "A logon was attempted using explicit credentials."),
    4672: ("Special privileges", "medium", "Special privileges were assigned to a new logon."),
    4688: ("Process creation", "info", "A new process was created. Command line visibility depends on audit policy."),
    4697: ("Service installed", "high", "A service was installed in the system."),
    4720: ("User created", "high", "A user account was created."),
    4722: ("User enabled", "medium", "A user account was enabled."),
    4724: ("Password reset", "high", "An attempt was made to reset an account password."),
    4726: ("User deleted", "high", "A user account was deleted."),
    4732: ("Member added to local group", "high", "A member was added to a security-enabled local group."),
    4733: ("Member removed from local group", "medium", "A member was removed from a security-enabled local group."),
    4740: ("Account locked out", "medium", "A user account was locked out."),
    7045: ("Service installed (System)", "high", "A service was installed. Commonly seen in the System log."),
    1102: ("Audit log cleared", "critical", "The Windows Security audit log was cleared."),
}

def explain(event_id: int) -> dict:
    name, severity, description = EVENTS.get(event_id, ("Unknown/uncatalogued event", "unknown", "No local description is available."))
    return {"event_id": event_id, "name": name, "severity": severity, "description": description}
