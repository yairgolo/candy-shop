$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
New-Item -ItemType Directory -Force -Path .\offline\wheels | Out-Null
python -m pip download -r requirements.txt -d .\offline\wheels
Write-Host "Downloaded Python wheels into offline\wheels"
