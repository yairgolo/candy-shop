$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
& .\.venv\Scripts\python.exe -m app.import_logs .\samples\sample_events.csv
