$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$env:LLM_URL = "http://127.0.0.1:8080/v1"
$env:LLM_MODEL = "local-qwen"
& .\.venv\Scripts\python.exe -m app.chat
