$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

if (!(Test-Path ".venv")) { python -m venv .venv }
& .\.venv\Scripts\python.exe -m pip install --no-index --find-links .\offline\wheels -r requirements.txt
Write-Host "Python environment ready."
Write-Host "Next: put llama-server.exe files in .\offline\llama\ and Qwen GGUF in .\offline\models\."
