$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Server = Join-Path $Root "offline\llama\llama-server.exe"
$Model = Join-Path $Root "offline\models\Qwen3-4B-Q4_K_M.gguf"
if (!(Test-Path $Server)) { throw "Missing $Server" }
if (!(Test-Path $Model)) { throw "Missing $Model" }
& $Server -m $Model --host 127.0.0.1 --port 8080 --jinja -c 8192 -n 2048
