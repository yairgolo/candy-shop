from pathlib import Path
from tempfile import TemporaryDirectory
from app.import_logs import import_csv
from app.db import connect

def test_import_sample():
    with TemporaryDirectory() as td:
        db = Path(td) / "x.db"
        sample = Path(__file__).resolve().parents[1] / "samples" / "sample_events.csv"
        n = import_csv(sample, str(db))
        assert n == 9
        con = connect(db)
        assert con.execute("select count(*) from events where event_id=4625").fetchone()[0] == 3
