# Windows Event Log MCP Assistant (Air-Gap MVP)

A small offline project that lets a local LLM answer natural-language questions about Windows Event Logs by calling MCP tools.

## Architecture

User -> local Qwen model (llama.cpp) -> MCP client -> Windows Event MCP server -> SQLite -> EVTX/CSV

The model does NOT receive the whole log. It sees MCP tool descriptions, decides which tool to call, receives only matching events, and writes the answer.

## MCP tools

- `search_events`
- `get_failed_logons`
- `get_process_events`
- `get_security_changes`
- `explain_event`
- `investigate_host`
- `database_stats`

## Quick test with bundled CSV

1. Create venv and install requirements.
2. `python -m app.import_logs samples/sample_events.csv`
3. Start local llama.cpp server with Qwen3-4B GGUF and `--jinja`.
4. `python -m app.chat`
5. Ask: `מה קרה ב-PC-17 בסביבות 03:00?`

## Import a real EVTX

Copy e.g. `Security.evtx` into the project and run:

`python -m app.import_logs Security.evtx`

You may import more than one file; all events are appended to the same SQLite DB.

## Notes

- Event 4688 command-line detail depends on Windows audit policy and the data present in the EVTX.
- This is an analyst-assistance demo, not a SIEM or detection product.
- No internet is used at runtime.
